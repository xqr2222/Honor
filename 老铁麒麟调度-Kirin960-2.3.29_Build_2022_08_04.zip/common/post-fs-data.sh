#!/system/bin/sh
MODDIR=${0%/*}
#(弃用)重定向文件

#启用省电核心
chown root root /sys/module/workqueue/parameters/power_efficient 
	echo Y > /sys/module/workqueue/parameters/power_efficient
		chmod 0644 /sys/module/workqueue/parameters/power_efficient
		
#处理器控制器
	#小核
chown root root /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
chown root root /sys/devices/system/cpu/cpu0/cpufreq/interactive/above_hispeed_delay
chown root root /sys/devices/system/cpu/cpu0/cpufreq/interactive/hispeed_freq
chown root root /sys/devices/system/cpu/cpu0/cpufreq/interactive/go_hispeed_load
chown root root /sys/devices/system/cpu/cpu0/cpufreq/interactive/target_loads
chown root root /sys/devices/system/cpu/cpu0/cpufreq/interactive/min_sample_time
chown root root /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq
chown root root /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq
chown root root /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_cur_freq
	echo "interactive" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
	echo "38000 1680000:98000" > /sys/devices/system/cpu/cpu0/cpufreq/interactive/above_hispeed_delay
	echo 533000 > /sys/devices/system/cpu/cpu0/cpufreq/interactive/hispeed_freq
	echo 97 > /sys/devices/system/cpu/cpu0/cpufreq/interactive/go_hispeed_load
	echo "80 980000:97 1380000:78 1680000:98" > /sys/devices/system/cpu/cpu0/cpufreq/interactive/target_loads
	echo 78000 > /sys/devices/system/cpu/cpu0/cpufreq/interactive/min_sample_time
	echo 1844000 > /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq
	echo 533000 > /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq
	echo 999000 > /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_cur_freq
		chmod 0644 /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
		chmod 0644 /sys/devices/system/cpu/cpu0/cpufreq/interactive/above_hispeed_delay
		chmod 0644 /sys/devices/system/cpu/cpu0/cpufreq/interactive/hispeed_freq
		chmod 0644 /sys/devices/system/cpu/cpu0/cpufreq/interactive/go_hispeed_load
		chmod 0644 /sys/devices/system/cpu/cpu0/cpufreq/interactive/target_loads
		chmod 0644 /sys/devices/system/cpu/cpu0/cpufreq/interactive/min_sample_time
		chmod 0644 /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq
		chmod 0644 /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq
		chmod 0644 /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_cur_freq
	#大核
chown root root /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
chown root root /sys/devices/system/cpu/cpu4/cpufreq/interactive/above_hispeed_delay
chown root root /sys/devices/system/cpu/cpu4/cpufreq/interactive/hispeed_freq
chown root root /sys/devices/system/cpu/cpu4/cpufreq/interactive/go_hispeed_load
chown root root /sys/devices/system/cpu/cpu4/cpufreq/interactive/target_loads
chown root root /sys/devices/system/cpu/cpu4/cpufreq/interactive/min_sample_time
chown root root /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq
chown root root /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_min_freq
chown root root /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_cur_freq
	echo "interactive"> /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
	echo "18000 1380000:98000 1780000:138000" > /sys/devices/system/cpu/cpu4/cpufreq/interactive/above_hispeed_delay
	echo 903000 > /sys/devices/system/cpu/cpu4/cpufreq/interactive/hispeed_freq
	echo 95 > /sys/devices/system/cpu/cpu4/cpufreq/interactive/go_hispeed_load
	echo "80 1380000:59 1805000:93 2112000:98" > /sys/devices/system/cpu/cpu4/cpufreq/interactive/target_loads
	echo 38000 > /sys/devices/system/cpu/cpu4/cpufreq/interactive/min_sample_time
	echo 2362000 > /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq
	echo 90300 > /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_min_freq
	echo 1805000 > /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_cur_freq
		chmod 0644 /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
		chmod 0644 /sys/devices/system/cpu/cpu4/cpufreq/interactive/above_hispeed_delay
		chmod 0644 /sys/devices/system/cpu/cpu4/cpufreq/interactive/hispeed_freq
		chmod 0644 /sys/devices/system/cpu/cpu4/cpufreq/interactive/go_hispeed_load
		chmod 0644 /sys/devices/system/cpu/cpu4/cpufreq/interactive/target_loads
		chmod 0644 /sys/devices/system/cpu/cpu4/cpufreq/interactive/min_sample_time
		chmod 0644 /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq
		chmod 0644 /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_min_freq
		chmod 0644 /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_cur_freq
	
#GPU设定 
chown root root /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/mali_ondemand/vsync
chown root root /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/min_freq
chown root root /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/cur_freq
chown root root /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/target_ferq
chown root root /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/max_freq
chown root root /sys/devices/platform/e82c0000.mali/power_policy
	echo 178000000 > /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/min_freq
	echo 178000000 > /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/cur_freq
	echo 178000000 > /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/target_ferq
	echo 1037000000 > /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/max_freq
	echo "coarse_demand" > /sys/devices/platform/e82c0000.mali/power_policy
	echo 0 > /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/mali_ondemand/vsync
		chmod 0644 /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/min_freq
		chmod 0644 /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/cur_freq
		chmod 0644 /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/target_ferq
		chmod 0644 /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/gpu_scene_aware/vsync
		chmod 0644 /sys/devices/platform/e82c0000.mali/power_policy
		chmod 0644 /sys/devices/platform/e82c0000.mali/devfreq/gpufreq/max_freq
# (弃用)关闭selinux
#setenforce 0

#处理器核心分配
chown root root /dev/cpuset/cpus 
chown root root /dev/cpuset/background/cpus
chown root root /dev/cpuset/foreground/cpus
chown root root /dev/cpuset/key-background/cpus
chown root root /dev/cpuset/system-background/cpus
chown root root /dev/cpuset/top-app/cpus
	echo "0-5" > /dev/cpuset/boost/cpus
	echo "2-3" > /dev/cpuset/background/cpus
	echo "0-4" > /dev/cpuset/foreground/cpus
	echo "0-7" > /dev/cpuset/key-background/cpus
	echo "0-3" > /dev/cpuset/system-background/cpus
	echo "0-7" > /dev/cpuset/top-app/cpus
		chmod 0644 /dev/cpuset/boost/cpus
		chmod 0644 /dev/cpuset/background/cpus
		chmod 0644 /dev/cpuset/foreground/cpus
		chmod 0644 /dev/cpuset/key-background/cpus
		chmod 0644 /dev/cpuset/system-background/cpus
		chmod 0644 /dev/cpuset/top-app/cpus
		
#DDR
chown root root /sys/class/devfreq/ddrfreq_up_threshold/max_freq
chown root root /sys/class/devfreq/ddrfreq_up_threshold/min_freq
chown root root /sys/class/devfreq/ddrfreq/min_freq
chown root root /sys/class/devfreq/ddrfreq/max_freq
chown root root /sys/class/devfreq/ddrfreq_latency/min_freq
chown root root /sys/class/devfreq/ddrfreq_latency/max_freq
chown root root /sys/class/devfreq/ddrfreq/min_freq
chown root root /sys/class/devfreq/ddrfreq/max_freq
chown root root /sys/class/devfreq/ddrfreq_latency/min_freq
chown root root /sys/class/devfreq/ddrfreq_latency/max_freq
chown root root /sys/class/devfreq/ddrfreq_up_threshold/max_freq
chown root root /sys/class/devfreq/ddrfreq_up_threshold/min_freq
	echo 1866000000 > /sys/class/devfreq/ddrfreq_up_threshold/max_freq
	echo 400000000 > sys/class/devfreq/ddrfreq_up_threshold/min_freq
	echo 400000000 > /sys/class/devfreq/ddrfreq/min_freq
	echo 1866000000 > /sys/class/devfreq/ddrfreq/max_freq
	echo 400000000 > /sys/class/devfreq/ddrfreq_latency/min_freq
	echo 1866000000 > /sys/class/devfreq/ddrfreq_latency/max_freq
	echo 400000000 > /sys/class/devfreq/ddrfreq_latency/min_freq
	echo 1866000000 > /sys/class/devfreq/ddrfreq_latency/max_freq
		chmod 0644 /sys/class/devfreq/ddrfreq_up_threshold/max_freq
		chmod 0644 /sys/class/devfreq/ddrfreq_up_threshold/min_freq
		chmod 0644 /sys/class/devfreq/ddrfreq/min_freq
		chmod 0644 /sys/class/devfreq/ddrfreq/max_freq
		chmod 0644 /sys/class/devfreq/ddrfreq_latency/min_freq
		chmod 0644 /sys/class/devfreq/ddrfreq_latency/max_freq
		chmod 0644 /sys/class/devfreq/ddrfreq/min_freq
		chmod 0644 /sys/class/devfreq/ddrfreq/max_freq
		chmod 0644 sys/class/devfreq/ddrfreq_latency/min_freq
		chmod 0644 /sys/class/devfreq/ddrfreq_latency/max_freq
		
#ZRAM/SWAP/VM
chown root root /sys/block/zram0/max_comp_streams
chown root root /sys/block/zram0/comp_algorithm
chown root root /sys/block/zram0/disksize
	echo 8 > /sys/block/zram0/max_comp_streams
	echo "lz4" > /sys/block/zram0/comp_algorithm
	echo 2348810240 > /sys/block/zram0/disksize #字节  2GB
		chmod 0644 /sys/block/zram0/max_comp_streams
		chmod 0644 /sys/block/zram0/comp_algorithm
		chmod 0644 /sys/block/zram0/disksize
	#VM控制器
chown root root /proc/sys/vm/swappiness
chown root root /proc/sys/vm/compact_unevictable_allowed
chown root root /proc/sys/vm/overcommit_ratio
chown root root /proc/sys/vm/overcommit_memory
chown root root /proc/sys/vm/panic_on_oom
chown root root /proc/sys/vm/page-cluster
chown root root /proc/sys/vm/oom_kill_allocating_task
chown root root /proc/sys/vm/exta_free_kbytes
	echo 65 > /proc/sys/vm/swappiness
	echo 1 > /proc/sys/vm/compact_unevictable_allowed
	echo 50 > proc/sys/vm/overcommit_ratio
	echo 1 > /proc/sys/vm/overcommit_memory
	echo 0 > /proc/sys/vm/oom_kill_allocating_task
	echo 1 > /proc/sys/vm/panic_on_oom #oom触发抛弃异常动作
	echo 0 > /proc/sys/vm/page-cluster
	echo 24300 > /proc/sys/vm/exta_free_kbytes
	
#HMP bootst
chown root root /sys/kernel/hmp/boost
	echo 0/sys/kernel/hmp/boost
		chmod 0644 /sys/kernel/hmp/boost
		
#(弃用)Hi3360 init
#chown root root /sys/devices/system/cpu/cpu0/cpufreq/interactive/hispeed_freq
#chown root root /sys/devices/system/cpu/cpu0/cpufreq/interactive/go_hispeed_load
#chown root root /sys/devices/system/cpu/cpu4/cpufreq/interactive/hispeed_freq
#chown root root /sys/devices/system/cpu/cpu4/cpufreq/interactive/go_hispeed_load
	#echo "x" > /sys/devices/system/cpu/cpu0/cpufreq/interactive/hispeed_freq
	#echo "x" > /sys/devices/system/cpu/cpu0/cpufreq/interactive/go_hispeed_load
	#echo "x" > /sys/devices/system/cpu/cpu4/cpufreq/interactive/hispeed_freq
	#echo "x" > /sys/devices/system/cpu/cpu4/cpufreq/interactive/go_hispeed_load
		#chmod 0644 /sys/devices/system/cpu/cpu0/cpufreq/interactive/hispeed_freq
		#chmod 0644 /sys/devices/system/cpu/cpu0/cpufreq/interactive/go_hispeed_load
		#chmod 0644 /sys/devices/system/cpu/cpu4/cpufreq/interactive/hispeed_freq
		#chmod 0644 /sys/devices/system/cpu/cpu4/cpufreq/interactive/go_hispeed
		
#LMK ＜API 28
chown root root /sys/module/lowmemorykiller/parameters/debug_level
chown root root /sys/module/lowmemorykiller/parameters/minfree
chown root root /sys/module/lowmemorykiller/parameters/vmpressure_file_min
chown root root /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
chown root root /sys/module/lowmemorykiller/parameters/oom_reaper
	echo 0 > /sys/module/lowmemorykiller/parameters/debug_level
	echo "4096,5120,8192,32768,56320,71680" > /sys/module/lowmemorykiller/parameters/minfree
	echo 53059 > sys/module/lowmemorykiller/parameters/vmpressure_file_min
	echo 0 > sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
	echo 1 > /sys/module/lowmemorykiller/parameters/oom_reaper
		chmod 0644 /sys/module/lowmemorykiller/parameters/debug_level
		chmod 0644 /sys/module/lowmemorykiller/parameters/minfree
		chmod 0644 /sys/module/lowmemorykiller/parameters/vmpressure_file_min
		chmod 0644 /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
		chmod 0644 /sys/module/lowmemorykiller/parameters/oom_reaper
	
#重定向文件
rm -f /data/powercfg.sh
cp /data/adb/modules/FE_KIRINcontrol_960/config/powercfg.sh /data
chmod 0644 /data/powercfg.sh

#Fstrim
/sbin/.magisk/busybox/fstrim -v /data
/sbin/.magisk/busybox/fstrim -v /userdata
/sbin/.magisk/busybox/fstrim -v /cache
/sbin/.magisk/busybox/fstrim -v /system
/sbin/.magisk/busybox/fstrim -v /vendor

#by Cirrest
#last build date 2022/08/04
#为什么华为这么封闭呢？
#后续计划:逐步弃用Magisk启动脚本
#			侧重于config.rc和vir interactive
#还有个锤子计划，P10屏幕都炸了。出了出了。