#!/system/bin/sh
#老铁麒麟调度    Fe Kirin control
#适用于麒麟960(hi3660)设备    Suitable for Kirin960(hi3660) device
#禁止二次修改！    DON'T second modification！
#允许您使用此项目对您的公开ROM/软件进行非盈利和商业行为的内嵌，但是需要您在项目、插件或ROM此类的介绍的明显位置标注：
#
#原作者：酷安@Cirrest
#原项目名称：Fe Kirin control
#
#Embed is allowed, but the information below MUST be notated at the beginning of your intro:
#
#Original Author：Coolapk@Cirrest
#Original Project：Fe Kirin control
#该文件脚本大部分已弃用，侧重于config.rc和vir interactive

#语法定义
IO_RABDOM="/sys/block/mmcblk0/queue/add_random"
IO_HELP="/sys/block/mmcblk0/queue/nomerges"
IO_STATS="/sys/block/mmcblk0/queue/iostats"
LMK_DEBUG="/sys/module/lowmemorykiller/parameters/debug_level"
LITTLE_INTERACTIVE="/sys/devices/system/cpu/cpu0/cpufreq/interactive"
BIG_INTERACTIVE="/sys/devices/system/cpu/cpu4/cpufreq/interactive"
GPU_MIN="/sys/devices/platform/e82c0000.mali/devfreq/gpufreq/min_freq"
GPU_MAX="/sys/devices/platform/e82c0000.mali/devfreq/gpufreq/max_freq"
LITTLE_CPUFREQ="/sys/devices/system/cpu/cpu0/cpufreq"
BIG_CPUFREQ="/sys/devices/system/cpu/cpu4/cpufreq"
BUSYBOX="/data/adb/magisk/busybox"
LITTLE_CPUMAX="/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq"
LITTLE_CPUMIN="/sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq"
BIG_CPUMAX="/sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq"
BIG_CPUMIN="/sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq"
# $1:timer_rate $2:value
function set_param_little() 
{
	echo ${2} > ${LITTLE_INTERACTIVE}/${1}
}

# $1:timer_rate $2:value
function set_param_big() 
{
	echo ${2} > ${BIG_INTERACTIVE}/${1}
}

# $1:timer_rate
function print_param() 
{
	print_value "LITTLE: ${1}" ${LITTLE_INTERACTIVE}/${1}
	print_value "big: ${1}" ${BIG_INTERACTIVE}/${1}
}

function unify_environment() 
{
	#关闭SELinux
	setenforce 0
	
    #核心控制
	lock_value 0 /sys/power/cpuhotplug/enabled
	lock_value 0 /sys/devices/system/cpu/cpuhotplug/enabled
	lock_value 1 /sys/devices/system/cpu/cpu4/online
	lock_value 1 /sys/devices/system/cpu/cpu5/online
	lock_value 1 /sys/devices/system/cpu/cpu6/online
	lock_value 1 /sys/devices/system/cpu/cpu7/online

    #调度选择
	lock_value "interactive" ${LITTLE_CPUFREQ}/scaling_governor
	lock_value "interactive" ${BIG_CPUFREQ}/scaling_governor
}

function runonce_custom()
{
	#CPUSET核心分配
	set_value 0-3 /dev/cpuset/background/cpus
	set_value 0-3 /dev/cpuset/system-background/cpus
	set_value 0-3,4-7 /dev/cpuset/foreground/cpus
	set_value 0-3,4-7 /dev/cpuset/top-app/cpus

	#基于HMP的响应时间参数
	lock_value 256 /sys/kernel/hmp/down_threshold
	lock_value 640 /sys/kernel/hmp/up_threshold
	lock_value 0 /sys/kernel/hmp/boost
}

#INTERACTIVE调度器
function before_modify()
{
	chown 0.0 ${LITTLE_INTERACTIVE}/*
	chmod 0666 ${LITTLE_INTERACTIVE}/*
	lock_value 480000 ${LITTLE_CPUFREQ}/scaling_min_freq

	set_value 1 /sys/devices/system/cpu/cpu4/online
	chown 0.0 ${BIG_INTERACTIVE}/*
	chmod 0666 ${BIG_INTERACTIVE}/*
	lock_value 880000 ${BIG_CPUFREQ}/scaling_min_freq
}

#权限设置
function after_modify()
{
	chmod 0444 ${LITTLE_INTERACTIVE}/*
	chmod 0444 ${BIG_INTERACTIVE}/*
	verify_param
}

function powersave_custom()
{
	:
}

function balance_custom()
{
	:
}

function performance_custom()
{
	:
}

function fast_custom()
{
	:
}



# $1:value $2:file pathij
function set_value() 
{
	if [ -f $2 ]; then
		echo $1 > $2
	fi
}

# $1:value $2:file path
function lock_value() 
{
	if [ -f $2 ]; then
		# chown 0.0 $2
		chmod 0666 $2
		echo $1 > $2
		chmod 0444 $2
	fi
}

#IO结构式
# $1:io-scheduler $2:block-path
function set_io() 
{
	if [ -f $2/queue/scheduler ]; then
		if [ `grep -c $1 $2/queue/scheduler` = 1 ]; then
			echo $1 > $2/queue/scheduler
			echo 1024 > $2/queue/read_ahead_kb
			lock_value 0 $2/queue/iostats
			lock_value 256 $2/queue/nr_requests
			lock_value 0 $2/queue/iosched/slice_idle
		fi
	fi
}

# $1:display-name $2:file path
function print_value() 
{
	if [ -f $2 ]; then
		echo $1
		cat $2
	fi
}
#VERIFY_INTERACTIVE调度器参数调试
function verify_param() 
{
	expected_target=${LITTLE_INTERACTIVE}/target_loads
	if [ "$action" = "powersave" ]; then		expected_value="80 980000:93 1380000:96"
	elif [ "$action" = "balance" ]; then
		expected_value="80 980000:97 1380000:78 1680000:98"
	elif [ "$action" = "performance" ]; then
		expected_value="80 980000:58 1380000:75 1680000:98"
	elif [ "$action" = "fast" ]; then
		expected_value="80 1780000:90"
	fi
	if [ "`cat ${expected_target}`" = "${expected_value}" ]; then
		echo "${action} DONE"
	else
		echo "${action} FAIL"
	fi
}

before_modify

#devinfo
action=$1
if [ ! -n "$action" ]; then
    action="balance"
fi

if [ ! -f /dev/.Fe_Kirin960 ]; then
	unify_environment
fi

#SCENE适配
if [ ! -f /dev/.Fe_Kirin960 ]; then
	#触发条件
	touch /dev/.Fe_Kirin960
	#RUN进行
	runonce_custom
    #i/o控制器设定
	set_io cfq /sys/block/mmcblk0
	set_io cfq /sys/block/sda
    #增加I/O随机性
    echo 1 > ${IO_RABDOM}
    #禁用LMK调试日志
    echo 0 > ${LMK_DEBUG}
    #禁用I/O调试帮助
    echo 0 > ${IO_HELP}
    #禁用I/O调度统计
    echo 0 > ${IO_STATS}
	#参数初始
	set_param_little timer_rate 20000
	set_param_little timer_slack 180000
	set_param_little boost 0
	set_param_little boostpulse_duration 0
	set_param_big timer_rate 20000
	set_param_big timer_slack 180000
	set_param_big boost 0
	set_param_big boostpulse_duration 0
fi

#省电模式
if [ "$action" = "powersave" ]; then
	powersave_custom
	set_param_little above_hispeed_delay "38000 1680000:98000"
	set_param_little hispeed_freq 533000
	echo "1844000"> ${LITTLE_CPUMAX}
	echo "533000"> ${LITTLE_CPUMIN}
	set_param_little go_hispeed_load 97
	set_param_little target_loads "80 980000:93 1380000:96"
	set_param_little min_sample_time 58000
	set_param_big above_hispeed_delay "18000 1780000:138000"
	set_param_big hispeed_freq 903000
	echo "2112000"> ${BIG_CPUMAX}
	echo "903000"> ${BIG_CPUMIN}
	set_param_big go_hispeed_load 84
	set_param_big target_loads "80 1380000:98"
	set_param_big min_sample_time 38000
	lock_value 903000 ${BIG_CPUFREQ}/scaling_min_freq
	lock_value 533000 ${LITTLE_CPUFREQ}/scaling_min_freq
	echo "178000000"> ${GPU_MIN}
    echo "533000000"> ${GPU_MAX}
fi

#平衡模式
if [ "$action" = "balance" ]; then
	balance_custom
	set_param_little above_hispeed_delay "38000 1680000:98000"
	set_param_little hispeed_freq 533000
	echo "1844000"> ${LITTLE_CPUMAX}
	echo "533000"> ${LITTLE_CPUMIN}
	set_param_little go_hispeed_load 97
	set_param_little target_loads "80 980000:97 1380000:78 1680000:98"
	set_param_little min_sample_time 78000
	set_param_big above_hispeed_delay "18000 1380000:98000 1780000:138000"
	set_param_big hispeed_freq 903000
	echo "2362000"> ${BIG_CPUMAX}
	echo "903000"> ${BIG_CPUMIN}
	set_param_big go_hispeed_load 95
	set_param_big target_loads "80 1380000:59 1780000:98"
	set_param_big min_sample_time 38000
	lock_value 903000 ${BIG_CPUFREQ}/scaling_min_freq
	lock_value 533000 ${LITTLE_CPUFREQ}/scaling_min_freq
	echo "178000000"> ${GPU_MIN}
    echo "807000000"> ${GPU_MAX}
fi

#性能
if [ "$action" = "performance" ]; then
	performance_custom
	set_param_little above_hispeed_delay "38000"
	set_param_little hispeed_freq 999000
	echo "1844000"> ${LITTLE_CPUMAX}
	echo "999000"> ${LITTLE_CPUMIN}
	set_param_little go_hispeed_load 97
	set_param_little target_loads "80 980000:58 1380000:75 1680000:98"
	set_param_little min_sample_time 78000
	set_param_big above_hispeed_delay "18000 1380000:38000 1780000:138000"
	set_param_big hispeed_freq 903000
	echo "2362000"> ${BIG_CPUMAX}
	echo "903000"> ${BIG_CPUMIN}
	set_param_big go_hispeed_load 93
	set_param_big target_loads "80 1380000:59 1780000:97"
	set_param_big min_sample_time 38000
	lock_value 903000 ${BIG_CPUFREQ}/scaling_min_freq
	lock_value 999000 ${LITTLE_CPUFREQ}/scaling_min_freq
	echo "400000000"> ${GPU_MIN}
    echo "1037000000"> ${GPU_MAX}
fi

#极速
if [ "$action" = "fast" ]; then
	fast_custom
	set_param_little above_hispeed_delay "18000 1680000:198000"
	set_param_little hispeed_freq 1402000
	echo "1844000"> ${LITTLE_CPUMAX}
	echo "1402000"> ${LITTLE_CPUMIN}
	set_param_little target_loads "80 1780000:90"
	set_param_little min_sample_time 38000
	set_param_big above_hispeed_delay "18000 1780000:198000"
	set_param_big hispeed_freq 1421000
	echo "2362000"> ${BIG_CPUMAX}
	echo "1421000"> ${BIG_CPUMIN}
	set_param_big target_loads "80 1980000:90"
	set_param_big min_sample_time 38000
	lock_value 1421000 ${BIG_CPUFREQ}/scaling_min_freq
	lock_value 1402000 ${LITTLE_CPUFREQ}/scaling_min_freq
	echo "533000000"> ${GPU_MIN}
    echo "1037000000"> ${GPU_MAX}
fi

after_modify
exit 0
#by Cirrest
#last build date 2022/08/04