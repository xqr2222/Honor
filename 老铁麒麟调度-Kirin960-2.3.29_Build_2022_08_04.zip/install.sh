SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
#语法定义
id="`grep_prop id $TMPDIR/module.prop`"
var_device="`grep_prop ro.product.*device`"
var_version="`grep_prop ro.build.version.release`"
B="`grep_prop author $TMPDIR/module.prop`"
C="`grep_prop name $TMPDIR/module.prop`"
#(弃用)模块说明显示
D="`grep_prop description $TMPDIR/module.prop`"
BUSYBOX="/data/adb/magisk/busybox"
ui_print "- $C    "
ui_print "- 设备: $var_device"
ui_print "- 系统: $var_version"
ui_print "- 作者：$B"
#查找并删除旧模块
ui_print "- 查找并删除旧模块"
rm -rf /data/adb/modules/KIRIN960EASLinks
rm -f /data/powercfg.sh
rm -rf /data/adb/modules/FE_KIRINcontrol_960
ui_print "- 提取文件"
unzip -o "$ZIPFILE" 'config/*' -d $MODPATH >&2
ui_print "- 执行文件配置"
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
${BUSYBOX} fstrim /data 2>/dev/null
${BUSYBOX} fstrim /cache 2>/dev/null
${BUSYBOX} fstrim /system 2>/dev/null
${BUSYBOX} fstrim /userdata 2>/dev/null
sm fstrim 2>/dev/null
#Copy&权限定义
cp $MODPATH/config/powercfg.sh /data
chmod 0644 /data/powercfg.sh
ui_print "请停用其它调度和与本模块功能重复的模块"
ui_print "需要重启设备，可Scene工具箱“性能配置”中切换调度模式。"
ui_print "原生安卓使用请重启2次，第一次请通过Magisk内重启选项重启。"
ui_print "build 2022/08/04"
set_perm_recursive  $MODPATH  0  0  0755  0644